   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2019 Online Library Management System |<a href="#" target="_blank"  > Designed by : Anurag, Dinesh & Prajnal</a>
                </div>

            </div>
        </div>
    </section>
